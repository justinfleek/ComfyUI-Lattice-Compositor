#include "patheffectcaller.h"

PathEffectCaller::PathEffectCaller()
{

}
