# Firecracker Crate Structure under Buck2
# Core hypervisor migration targets

load("///prelude/prelude.bzl", "isospin_rust_binary", "isospin_rust_library", "firecracker_seccomp_library")

# Core VMM Library - Most critical dependency
isospin_rust_library(
    name = "vmm_lib",
    srcs = glob([
        "vmm/src/**/*.rs",
        "vmm/build.rs"
    ]),
    deps = [
        "//firecracker/src/utils:utils_lib",
        "//firecracker/src/acpi-tables:acpi_tables_lib",
        "//3rdparty/rust:kvm_bindings",
        "//3rdparty/rust:kvm_ioctls",
        "//3rdparty/rust:vm_memory",
        "//3rdparty/rust:vmm_sys_util",
    ],
)

# Utils Library - Shared infrastructure
isospin_rust_library(
    name = "utils_lib",
    srcs = glob(["utils/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:serde",
        "//3rdparty/rust:serde_json",
        "//3rdparty/rust:libc",
        "//3rdparty/rust:nix",
    ],
)

# ACPI Tables Library - Platform support  
isospin_rust_library(
    name = "acpi_tables_lib",
    srcs = glob(["acpi-tables/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:libc",
        "//3rdparty/rust:errno",
    ],
)

# Seccompiler Tool - Critical for security
isospin_rust_binary(
    name = "seccompiler_binary",
    srcs = glob(["seccompiler/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:seccompiler",
        "//3rdparty/rust:serde",
        "//3rdparty/rust:serde_json",
    ],
)

# Firecracker Binary - Main target
isospin_rust_binary(
    name = "firecracker_binary",
    srcs = glob(["firecracker/src/**/*.rs"]),
    deps = [
        ":vmm_lib",
        ":utils_lib",
        "//3rdparty/rust:kvm_ioctls",
        "//3rdparty/rust:serde",
        "//3rdparty/rust:serde_json",
    ],
)

# Seccomp Policies - Security critical
firecracker_seccomp_library(
    name = "seccomp_policies",
    policies_dir = "resources/seccomp",
)