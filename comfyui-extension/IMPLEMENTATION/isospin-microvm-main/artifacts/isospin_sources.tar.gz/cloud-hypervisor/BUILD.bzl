# Cloud Hypervisor Crate Structure under Buck2
# Modular VMM architecture migration targets

load("///prelude/prelude.bzl", "isospin_rust_binary", "isospin_rust_library")

# Core VMM Library - Central VMM implementation
isospin_rust_library(
    name = "vmm_lib",
    srcs = glob([
        "vmm/src/**/*.rs",
        "vmm/build.rs"
    ]),
    deps = [
        ":hypervisor_lib",
        ":devices_lib",
        ":pci_lib",
        ":arch_lib",
        ":vm_allocator_lib",
        ":vm_device_lib",
        "//3rdparty/rust:kvm_bindings",
        "//3rdparty/rust:kvm_ioctls",
        "//3rdparty/rust:vm_memory",
        "//3rdparty/rust:serde",
        "//3rdparty/rust:tokio",
    ],
)

# Hypervisor Abstraction Layer - KVM backend
isospin_rust_library(
    name = "hypervisor_lib",
    srcs = glob(["hypervisor/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:kvm_bindings",
        "//3rdparty/rust:kvm_ioctls",
        "//3rdparty/rust:libc",
        "//3rdparty/rust:thiserror",
    ],
)

# Devices Library - Basic device management (VFIO excluded)
isospin_rust_library(
    name = "devices_lib",
    srcs = glob(["devices/src/**/*.rs"]),
    deps = [
        ":pci_lib",
        ":vm_device_lib",
        "//3rdparty/rust:virtio_queue",
        "//3rdparty/rust:virtio_bindings",
        "//3rdparty/rust:libc",
        "//3rdparty/rust:serde",
    ],
)

# PCI Library - Core PCI management (VFIO excluded)
isospin_rust_library(
    name = "pci_lib",
    srcs = glob(["pci/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:libc",
        "//3rdparty/rust:serde",
        "//3rdparty/rust:thiserror",
        "//3rdparty/rust:errno",
    ],
)

# Architecture Library - Platform-specific code
isospin_rust_library(
    name = "arch_lib",
    srcs = glob(["arch/src/**/*.rs"]),
    deps = [
        ":hypervisor_lib",
        ":vmm_lib",
        "//3rdparty/rust:libc",
    ],
)

# VM Allocator - Memory management
isospin_rust_library(
    name = "vm_allocator_lib",
    srcs = glob(["vm-allocator/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:libc",
        "//3rdparty/rust:libc",
    ],
)

# VM Device - Device abstraction
isospin_rust_library(
    name = "vm_device_lib",
    srcs = glob(["vm-device/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:libc",
        "//3rdparty/rust:serde",
    ],
)

# Cloud Hypervisor Binary - Main target
isospin_rust_binary(
    name = "cloud_hypervisor_binary",
    srcs = glob(["cloud-hypervisor/src/**/*.rs"]),
    deps = [
        ":vmm_lib",
        ":arch_lib",
        "//3rdparty/rust:clap",
        "//3rdparty/rust:serde_json",
        "//3rdparty/rust:tokio",
    ],
)

# API Client - Management interface
isospin_rust_library(
    name = "api_client_lib",
    srcs = glob(["api_client/src/**/*.rs"]),
    deps = [
        "//3rdparty/rust:serde",
        "//3rdparty/rust:serde_json",
        "//3rdparty/rust:reqwest",
    ],
)