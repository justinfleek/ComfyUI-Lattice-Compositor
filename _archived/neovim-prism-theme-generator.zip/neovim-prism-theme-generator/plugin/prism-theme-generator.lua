-- Auto-load plugin
require('prism-theme-generator').setup()
