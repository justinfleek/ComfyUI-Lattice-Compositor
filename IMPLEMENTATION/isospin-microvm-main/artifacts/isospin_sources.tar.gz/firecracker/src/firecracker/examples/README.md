## Test Utilities

The `examples` directory contains various small rust utilities that are used in
firecracker's integration test suite.
